# Current desktop implementation

The desktop uses the existing Vue components in `apps/desktop/ui/`, Tauri commands in `apps/desktop/src/shell.rs`, and the independent Rust core in `apps/desktop/src/game_core/`. Its active styles are `apps/desktop/tokens.css` and `apps/desktop/launcher.css`: OLED black, Dawn Gold `#E9B86D`, a permanent 68px icon rail, and a 44px header. Settings open in centered dialogs. Instance pages open on Content. Global Discover installs modpacks as new instances; the instance browser installs individual content, with datapacks scoped to a saved world.

`node scripts/verify-redesign-e2e.cjs` checks the built frontend using explicitly mocked native/provider responses. It covers launch/window policy, crash states, content job completion/failure, bulk actions, settings, file-save conflicts, live logs, skin editing/rendering and lazy screenshots. These checks do not establish live Microsoft or Windows gameplay acceptance.

For the real Linux shell, build with `npx tauri build --debug --no-bundle --config apps/desktop/tauri.conf.json`, then run `xvfb-run -a -s '-screen 0 1440x900x24' python3 scripts/check-native-smoke.py`. The smoke test uses temporary XDG directories and a labelled instance fixture. It verifies preserved world bytes, migration from the legacy Close default to Keep Open, and native Settings keyboard interaction. Local screenshots remain under ignored `checks/continuation/`. Physical Windows installation, Credential Manager, licensed gameplay and updater replacement still require Windows testing.

The notes below describe earlier designs and their historical verification scripts; they do not override the current desktop layout or acceptance limits.

# Solara visual design — current direction

Latest owner direction, 2026-10-31: a bright, colourful desktop with large icons, readable controls and a substantial welcome screen. The owner explicitly rejected the previous dark-green design. The desktop now uses lilac paper (`#f6f3fc`), white panels and lavender, sky-blue, peach and pink sections. Violet (`#7650dc`) is the new-install accent; saved user choices are preserved, with contrast-aware button text. The existing compact launcher structure remains, enlarged to a labelled94px rail, ~44px action controls,14–16px body/control text and a310px dashboard welcome. Seasons remain deferred with `features.seasons=false`.

This is a local UI revision after published V-0.0.14. The owner explicitly assigned subsequent publishing/updater delivery to Gemini. These source edits have not been pushed, packaged or added to V14; its signed immutable artifacts remain unchanged.

## Layout and imagery

The icon rail contains accessible navigation labels/tooltips, a create action and shortcuts to actual local instances. The single top toolbar provides guarded navigation history, working content search on larger windows, observed running-game state, separate account actions and downloads. Home starts with a large illustrated welcome and a list of installed/running local instances, followed by the library. It does not copy the reference's server counts or play-time data. Instance tiles use original vector loader symbols on coloured geometric backgrounds, never generated landscape thumbnails. Loaders, versions and running state come from the native snapshot. `InstanceAvatar.vue` shares the same icon across the sidebar, recent instances, library and instance header. `InstanceAppearance.vue` accepts a personal PNG/JPG/WebP <=5MB/16MP and stores a cropped256px image locally per instance; upload/reset is available in instance settings and the edit dialog. The image stays on this device in appearance preferences, is not uploaded, and is not included in world backups. Unsupported/unreadable files and storage failures produce clear errors. Quick starts install clean game/loader setups and make no claims about bundled mods.

`ContextRail.vue` keeps Playing as, Solara identity, a working preferences link and Solara services available beside Home, Library and instance pages. It collapses below 1100px so small desktop windows retain usable content width. Its geometric slider illustration is original CSS; the service image is existing Solara artwork. Discover places supported content categories to the right of readable project rows. Instance headers have large loader symbols and readable pill tabs. Create-instance choices are stacked, with the existing two supported paths. Library, services, preferences, instance files/mods/backups/screenshots/logs and dialogs share the desktop tokens. Upstream skins, subscriptions, sync promotions and unsupported import actions are not represented as working Solara features.

Guest, empty, cached and unavailable states remain visible. Popularity counts are shown only when returned by the content provider. The snapshot dialog describes its actual world/config backup scope; it excludes mods, resource packs and shaders. Creating a similar instance creates a fresh setup with matching version/loader rather than claiming to copy user files.

`packages/ui/WorldArt.vue` renders original illustrative landscape WebPs with actual load/decode fade, pending indicator and failure fallback. Artwork is generated with built-in imagegen, visually reviewed. It is not a screenshot of an actual user world or installed pack. Full-size/thumbnail delivery assets total 1,765,840 bytes; original PNGs remain in `assets/artwork/source/` outside the shipped public directory. No external image service is needed.

Active desktop styling is `packages/ui/base.css`, `packages/ui/motion.css` and `apps/desktop/launcher.css`. The old desktop/reference/workspace stylesheets remain historical source and are no longer imported. Website styling remains separate in `apps/website/website.css` and its existing entrypoint imports. No upstream interface code or brand assets were copied for this redesign.

## Loading and motion

- Startup waits for actual interface images/fonts and native initialization. There is no invented progress percentage or minimum splash duration. Interface-resource waiting is bounded to eight seconds; failed images fall back instead of trapping the app. Native failure offers retry or browsing without a working engine.
- Public API loading does not gate local startup. Catalogue skeletons appear while a real public request is pending and there is no data; cached listings remain visible during refresh. Concurrent public refreshes are deduplicated.
- Discovery has actual provider-request pending, success, empty and failure states. `WorkspaceLoading.vue` supplies colourful skeleton cards and request status; `TaskProgress.vue` supplies local-file/update loading. It never invents popular content or installed instances.
- Update and download bars use actual native downloaded/total bytes (or an actual task fraction). Unknown totals use indeterminate progress. Waiting for idle is labelled without a running progress bar. No release automation or native update policy was changed for this revision.
- Distinct short navigation glyph, press, toggle, loader selection, page, image, dropdown, dialog and toast transitions provide movement when useful. Artwork does not constantly orbit or drift, and listing rows are manually scrollable.
- Page visibility pauses CSS motion. Offscreen pending artwork/skeletons pause. Reduced motion disables animations/transitions and image hover zoom. No WebGL/canvas, animation framework or runtime remote fonts are added.
- Keyboard labels, focus-contained dialogs, nested Escape and custom dropdown keyboard behavior remain required.

`npm run test:motion` checks images/matte controls, real resource-driven startup, controlled provider pending/error states, native initialization UI through an explicitly labelled IPC test fixture, reduced motion and image fallback. Fixture checks are browser component evidence, never a native Windows acceptance claim. `npm run test:ui` checks actual navigation, controls and desktop/mobile layout.

## Screenshots and recording

`npm run capture:preview` captures the actual app and records `checks/solara-motion.webm`. For actual published catalogue data through the existing read-only local adapter, run it with `SOLARA_PREVIEW_API=http://127.0.0.1:1431` while the private dev server is running. No game accounts, installed instances or process activity are fabricated.

`npm run test:redesign` verifies search, loader filters, sidebar shortcuts, initial mod loading, guarded history, the snapshot modal, quick-start arguments, personal icon validation/upload/reload/reset, real native byte progress, reduced motion and layouts at 1440, 1100, 800 and 650 pixels. It captures a local review gallery at `checks/redesign/index.html`. Populated screens are explicitly labelled QA fixtures. Guest screenshots depict the actual browser preview with an unavailable API.

Publishable screenshots live in `public/screenshots/`; earlier designs are preserved locally under `checks/previous-design/`. Keep development previews labelled. Screenshots/recordings are browser evidence, not Windows game/SSO/provider acceptance, production deployment or an executable release.
