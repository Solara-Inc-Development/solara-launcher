<script setup lang="ts">
import {ref,computed} from 'vue';
import {ArrowRight,Plus,Play,Square,Layers3,Server,Compass,ArrowUpRight,RefreshCw,Box,Coffee,ShieldCheck,ChevronDown,FolderOpen,User,Search,Sparkles,Globe,Package} from '../../packages/ui/icons';
import LoaderMark from '../../packages/ui/LoaderMark.vue';
import SelectControl from '../../packages/ui/SelectControl.vue';
const props=withDefaults(defineProps<{instances:any[],projects:any[],services:any[],account:any,minecraft?:any[],loading:boolean,apiState:string}>(),{minecraft:()=>[]});
const emit=defineEmits(['open-instance','create','navigate','external','refresh','play','stop','account','copy','solara-signin','create-preset','duplicate','open-folder','discover']);
const librarySearch=ref(''),activeLibraryTab=ref('instances'),sortBy=ref('name'),loaderFilter=ref('all'),avatarFailed=ref(false);
const activeAccount=computed(()=>props.minecraft.find(a=>a.active)||null);
const recentInstances=computed(()=>[...props.instances].filter(i=>i.running||i.state==='installed').sort((a,b)=>Number(b.running)-Number(a.running)).slice(0,3));
const today=new Intl.DateTimeFormat('en-IN',{weekday:'long',day:'numeric',month:'short'}).format(new Date());
const scenes=['forest-valley','alpine-lake','coastal-hamlet','canyon-settlement','moss-cave','workshop'];
function art(instance:any){let hash=0;for(const char of instance.name||'')hash=(hash*31+char.charCodeAt(0))|0;return '/art/'+scenes[Math.abs(hash)%scenes.length]+'-v1-small.webp'}
function readPins():string[]{try{const value=JSON.parse(localStorage.getItem('solara:pinned-instances')||'[]');return Array.isArray(value)?value.filter(v=>typeof v==='string'):[]}catch{return []}}
const pinned=ref(readPins());
function togglePin(id:string){pinned.value=pinned.value.includes(id)?pinned.value.filter(v=>v!==id):[...pinned.value,id];try{localStorage.setItem('solara:pinned-instances',JSON.stringify(pinned.value))}catch{}}
const visibleInstances=computed(()=>props.instances.filter(i=>(loaderFilter.value==='all'||i.loader===loaderFilter.value)&&`${i.name} ${i.gameVersion} ${i.loader}`.toLowerCase().includes(librarySearch.value.trim().toLowerCase())).sort((a,b)=>Number(pinned.value.includes(b.id))-Number(pinned.value.includes(a.id))||(sortBy.value==='version'?(b.gameVersion||'').localeCompare(a.gameVersion||'',undefined,{numeric:true}):sortBy.value==='active'?Number(b.running)-Number(a.running)||a.name.localeCompare(b.name):a.name.localeCompare(b.name))));
const templates=[
 {id:'fabric',name:'Fabric essentials',loader:'fabric',gameVersion:'1.21.1',desc:'A lightweight foundation for your favourite mods.',tone:'mint',scene:'forest-valley'},
 {id:'vanilla',name:'Simply Minecraft',loader:'vanilla',gameVersion:'1.21.1',desc:'The original game. A fresh world of possibilities.',tone:'amber',scene:'coastal-hamlet'},
 {id:'forge',name:'Forge workshop',loader:'forge',gameVersion:'1.20.1',desc:'Start a classic Forge setup and add your own mods.',tone:'rose',scene:'workshop'},
 {id:'neoforge',name:'A new adventure',loader:'neoforge',gameVersion:'1.21.1',desc:'A clean NeoForge instance, ready to make your own.',tone:'violet',scene:'alpine-lake'},
 {id:'quilt',name:'Quilt canvas',loader:'quilt',gameVersion:'1.21.1',desc:'Build a personal mod collection with Quilt.',tone:'sky',scene:'canyon-settlement'}
];
const visibleTemplates=computed(()=>templates.filter(t=>`${t.name} ${t.loader}`.toLowerCase().includes(librarySearch.value.trim().toLowerCase())));
const discoveries=[{type:'mod',name:'A little more possibility.',label:'EXPLORE MODS',copy:'Small additions. A whole new experience.',scene:'workshop',tone:'amber',icon:Package},{type:'modpack',name:'Your next obsession.',label:'DISCOVER MODPACKS',copy:'Find a world someone else dreamed up.',scene:'coastal-hamlet',tone:'mint',icon:Box},{type:'shader',name:'See it differently.',label:'FIND SHADERS',copy:'Give a familiar world a fresh perspective.',scene:'alpine-lake',tone:'violet',icon:Sparkles}];
function play(instance:any){if(instance.running){emit('stop',instance);return}if(!activeAccount.value){emit('account');return}emit('play',instance)}
function status(value:string){return ['online','operational','connected'].includes(value?.toLowerCase())?'Available':value||'Status not reported'}
</script>
<template>
<section class="new-home">
  <div class="home-welcome"><div><span class="workspace-kicker">YOUR SPACE TO PLAY</span><h1>{{account?'Welcome back, '+(account.name||account.username)+'.':'Welcome to Solara.'}}</h1></div><div class="new-home-actions"><button class="workspace-play" @click="emit('create')"><Plus/> Create a world</button></div></div>
   <section v-if="recentInstances.length" class="jump-back-section" aria-label="Jump back in">
     <div class="workspace-section-heading"><h2>Jump back in</h2><span class="jump-section-note">Your local instances</span></div>
     <article v-for="inst in recentInstances" :key="inst.id" class="jump-instance-row"><button class="jump-instance-open" :aria-label="'Continue '+inst.name" @click="emit('open-instance',inst)"><img :src="art(inst)" alt=""><span><strong>{{inst.name}}</strong><small><LoaderMark :loader="inst.loader"/>{{inst.loader}} · Minecraft {{inst.gameVersion}}</small></span></button><span class="jump-instance-state" :class="{running:inst.running}"><span class="dot"/>{{inst.running?'Running':'Ready to play'}}</span><button class="workspace-play" :aria-label="(inst.running?'Stop recent instance ':'Play recent instance ')+inst.name" @click="play(inst)"><Square v-if="inst.running"/><Play v-else/>{{inst.running?'Stop':'Play'}}</button><button class="jump-manage" :aria-label="'Manage recent instance '+inst.name" @click="emit('open-instance',inst)"><ArrowUpRight/></button></article>
   </section>
  <div class="home-main-layout">
    <div class="home-content-column">
      <section class="home-library-section">
        <div class="library-header-row"><div class="library-title-group"><h2>Your library <span class="count-badge">{{instances.length}}</span></h2><p>A home for every kind of Minecraft.</p></div><button class="solara-btn-primary" @click="emit('create')"><Plus :size="15"/> New instance</button></div>
        <div class="library-tab-row"><div class="library-tab-pills" aria-label="Library categories"><button class="library-tab-pill" :class="{active:activeLibraryTab==='instances'}" :aria-pressed="activeLibraryTab==='instances'" @click="activeLibraryTab='instances'">My instances</button><button class="library-tab-pill" :class="{active:activeLibraryTab==='templates'}" :aria-pressed="activeLibraryTab==='templates'" @click="activeLibraryTab='templates'"><Sparkles :size="14"/> Quick starts</button></div><button class="text-link" @click="emit('navigate','launcher')">View library <ArrowRight :size="14"/></button></div>
        <div class="library-controls-bar"><label class="library-search-box"><Search :size="16"/><input v-model="librarySearch" placeholder="Find an instance…" aria-label="Search instances"></label><SelectControl v-if="activeLibraryTab==='instances'" v-model="sortBy" label="Sort home instances" :options="[{value:'name',label:'Name'},{value:'active',label:'Running first'},{value:'version',label:'Game version'}]"/></div>
        <div v-if="activeLibraryTab==='instances'&&instances.length" class="library-filter-pills"><button v-for="loader in ['all','fabric','quilt','forge','neoforge','vanilla'].filter(l=>l==='all'||instances.some(i=>i.loader===l))" :key="loader" class="filter-pill" :class="{active:loaderFilter===loader}" :aria-pressed="loaderFilter===loader" @click="loaderFilter=loader">{{loader==='all'?'All instances':loader}}</button></div>
        <template v-if="activeLibraryTab==='instances'">
          <div v-if="visibleInstances.length" class="solara-instance-grid">
            <article v-for="inst in visibleInstances" :key="inst.id" class="solara-instance-card" :class="{pinned:pinned.includes(inst.id)}">
              <button class="home-instance-cover" :aria-label="'Manage '+inst.name" @click="emit('open-instance',inst)"><img :src="art(inst)" alt="" loading="lazy"><span class="cover-loader"><LoaderMark :loader="inst.loader"/>{{inst.loader}}</span><span v-if="inst.running" class="cover-running"><span class="dot"/> Running</span></button>
              <div class="home-instance-body"><button class="home-instance-name" @click="emit('open-instance',inst)"><h3>{{inst.name}}</h3><span>Minecraft {{inst.gameVersion}}</span></button><div class="instance-card-actions"><button class="card-action-btn pin-btn" :class="{pinned:pinned.includes(inst.id)}" :aria-label="(pinned.includes(inst.id)?'Unpin ':'Pin ')+inst.name" :aria-pressed="pinned.includes(inst.id)" @click="togglePin(inst.id)">★</button><button class="card-action-btn" title="Open instance folder" @click="emit('open-folder',inst)"><FolderOpen :size="14"/></button><button class="instance-quick-play" :disabled="!inst.running&&inst.state!=='installed'" :aria-label="(inst.running?'Stop ':'Play ')+inst.name" @click="play(inst)"><Square v-if="inst.running" :size="14"/><Play v-else :size="14"/></button></div></div>
            </article>
          </div>
          <div v-else-if="instances.length" class="workspace-empty"><Search/><h3>No matching instances</h3><p>Try a different name or loader.</p><button @click="librarySearch='';loaderFilter='all'">Clear filters</button></div>
          <div v-else class="new-home-empty"><div class="empty-blocks" aria-hidden="true"><Box/><span><Plus/></span></div><h3>Your first world starts here.</h3><p>A fresh survival world? A modded adventure?<br>Start with a version and make it your own.</p><button class="solara-btn-primary" @click="emit('create')"><Plus :size="15"/> Create your first instance</button><button class="text-link" @click="activeLibraryTab='templates'">Or try a quick start <ArrowRight :size="13"/></button></div>
        </template>
        <template v-else><p class="template-explanation">Clean game and loader setups. Add the mods you love afterwards.</p><div class="solara-preset-grid"><article v-for="preset in visibleTemplates" :key="preset.id" class="preset-card" :data-tone="preset.tone"><img :src="'/art/'+preset.scene+'-v1-small.webp'" alt="" loading="lazy"><div class="preset-body"><span class="preset-loader"><LoaderMark :loader="preset.loader"/>{{preset.loader}} · {{preset.gameVersion}}</span><h3>{{preset.name}}</h3><p>{{preset.desc}}</p><button class="solara-btn-secondary" @click="emit('create-preset',preset)"><Plus :size="14"/> Create instance</button></div></article></div><div v-if="!visibleTemplates.length" class="workspace-empty"><Search/><p>No quick starts match your search.</p></div></template>
      </section>
      <section class="home-community-section"><div class="workspace-section-heading"><div><span class="workspace-kicker">A LITTLE INSPIRATION</span><h2>Make something of your own.</h2></div><button class="text-link" @click="emit('navigate','explore')">Discover more <ArrowRight :size="14"/></button></div><div class="home-discovery-grid"><button v-for="item in discoveries" :key="item.type" class="home-discovery-card" :data-tone="item.tone" @click="emit('discover',item.type)"><div class="discovery-card-art"><img :src="'/art/'+item.scene+'-v1-small.webp'" alt="" loading="lazy"><span><component :is="item.icon"/></span></div><div class="discovery-card-copy"><small>{{item.label}}</small><h3>{{item.name}}</h3><p>{{item.copy}}</p><ArrowUpRight :size="16"/></div></button></div></section>
      <section v-if="projects.length" class="home-projects"><div class="workspace-section-heading"><div><span class="workspace-kicker">THE SOLARA ECOSYSTEM</span><h2>More to explore.</h2></div></div><div class="home-project-grid"><button v-for="project in projects.slice(0,4)" :key="project.id" :disabled="!project.url" @click="emit('external',project.url)"><span class="project-sigil"><Layers3/></span><span><strong>{{project.name}}</strong><small>{{project.description}}</small></span><ArrowUpRight :size="15"/></button></div></section>
    </div>

  </div>
</section>
</template>
