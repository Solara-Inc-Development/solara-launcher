//! Solara's independently implemented native engine integration.
use crate::game_core::{
    auth::Accounts,
    download::{Cancellation, FileCache},
    extras,
    files::Files,
    instances::{write_json, Instances},
    java::Runtimes,
    jobs::Jobs,
    launch::Games,
    metadata,
};
use anyhow::{bail, Context, Result};
use serde_json::{json, Value};
use solara_local_server::{LocalServers, ServerConfig};
use std::{
    path::{Path, PathBuf},
    sync::atomic::{AtomicUsize, Ordering},
};
use tokio::sync::{watch, OnceCell};

struct DownloadGate {
    limit: AtomicUsize,
    active: std::sync::Mutex<usize>,
    notify_tx: watch::Sender<u64>,
}

struct DownloadPermit<'a> {
    gate: &'a DownloadGate,
}

impl Drop for DownloadPermit<'_> {
    fn drop(&mut self) {
        if let Ok(mut active) = self.gate.active.lock() {
            *active = active.saturating_sub(1);
        }
        self.gate.notify_tx.send_modify(|v| *v = v.wrapping_add(1));
    }
}

impl DownloadGate {
    fn new(limit: u32) -> Self {
        let (notify_tx, _) = watch::channel(0u64);
        Self {
            limit: AtomicUsize::new((limit.clamp(1, 8)) as usize),
            active: std::sync::Mutex::new(0),
            notify_tx,
        }
    }

    fn limit(&self) -> usize {
        self.limit.load(Ordering::Acquire).clamp(1, 8)
    }

    fn set_limit(&self, limit: u32) {
        self.limit.store((limit.clamp(1, 8)) as usize, Ordering::Release);
        self.notify_tx.send_modify(|v| *v = v.wrapping_add(1));
    }

    async fn acquire(&self) -> Result<DownloadPermit<'_>> {
        let mut rx = self.notify_tx.subscribe();
        loop {
            {
                let mut active = self
                    .active
                    .lock()
                    .map_err(|_| anyhow::anyhow!("Download concurrency state poisoned"))?;
                let limit = self.limit();
                if *active < limit {
                    *active += 1;
                    return Ok(DownloadPermit { gate: self });
                }
            }
            rx.changed()
                .await
                .map_err(|_| anyhow::anyhow!("Download queue closed"))?;
        }
    }
}

static ENGINE: OnceCell<Engine> = OnceCell::const_new();
pub struct Engine {
    pub local: LocalServers,
    pub data: PathBuf,
    pub instances: Instances,
    pub accounts: Accounts,
    pub games: Games,
    pub jobs: Jobs,
    pub java: Runtimes,
    pub files: Files,
    cache: FileCache,
    slots: DownloadGate,
    launching: std::sync::Mutex<std::collections::HashSet<String>>,
}

struct LaunchReservation<'a> {
    engine: &'a Engine,
    id: String,
}
impl Drop for LaunchReservation<'_> {
    fn drop(&mut self) {
        if let Ok(mut launching) = self.engine.launching.lock() {
            launching.remove(&self.id);
        }
    }
}
impl Engine {
    fn reserve_launch(&self, id: &str) -> Result<LaunchReservation<'_>> {
        let mut launching = self.launching.lock().map_err(|_| anyhow::anyhow!("Launch state unavailable"))?;
        if !launching.insert(id.to_string()) {
            bail!("This instance is already starting");
        }
        Ok(LaunchReservation { engine: self, id: id.to_string() })
    }
    fn is_launching(&self, id: &str) -> bool {
        self.launching.lock().map(|items| items.contains(id)).unwrap_or(true)
    }
}
pub async fn get() -> Result<&'static Engine> {
    ENGINE.get().context("Launcher engine is not initialized")
}
pub async fn initialize() -> Result<()> {
    ENGINE
        .get_or_try_init(|| async {
            let data = dirs::data_local_dir()
                .context("Local app-data folder unavailable")?
                .join("in.solara.launcher");
            tokio::fs::create_dir_all(&data).await?;
            if let Err(err) = migrate_clean_slate_v23(&data).await {
                eprintln!("[migration] could not retire the old V23 marker: {err:#}");
            }
            cleanup_stale_files(&data).await;
            let instances = Instances::new(data.join("custom-instances"));
            // A crashed/closed app cannot leave an instance permanently installing.
            for record in instances.list().await? {
                if record.state == "installing" {
                    instances
                        .transition(&record.id, &["installing"], "failed")
                        .await?;
                }
            }
            let initial_prefs = read_preferences_from_dir(&data).await.unwrap_or_default();
            Ok::<_, anyhow::Error>(Engine {
                local: LocalServers::new(data.join("local-servers")),
                instances,
                accounts: Accounts::new(data.join("custom-minecraft-accounts")),
                games: Games::default(),
                jobs: Jobs::default(),
                java: Runtimes::new(data.join("java-runtimes")),
                files: Files::default(),
                cache: FileCache::new(data.join("verified-game-files"))?,
                slots: DownloadGate::new(initial_prefs.max_concurrent_downloads),
                launching: Default::default(),
                data,
            })
        })
        .await?;
    Ok(())
}
async fn process_finished_games(engine: &Engine) {
    if let Ok(finished) = engine.games.collect_finished().await {
        for fg in finished {
            if fg.elapsed_seconds > 0 {
                let _ = engine
                    .instances
                    .change(&fg.instance_id, |i| {
                        i.playtime_seconds = i.playtime_seconds.saturating_add(fg.elapsed_seconds);
                    })
                    .await;
            }
            if let Some(hook) = fg
                .post_exit
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
            {
                let instance_id = fg.instance_id;
                let game_dir = fg.game_dir;
                tokio::spawn(async move {
                    if let Err(err) = crate::game_core::launch::run_hook(&hook, &game_dir).await {
                        eprintln!("[hooks] post-exit hook warning for {instance_id}: {err:#}");
                    }
                });
            }
        }
    }
}
pub async fn snapshot() -> Result<Value> {
    let engine = get().await?;
    process_finished_games(engine).await;
    let running = engine.games.running().await?;
    let raw_instances = engine.instances.list().await?;
    let mut instances = Vec::with_capacity(raw_instances.len());
    for i in raw_instances {
        let mut value = serde_json::to_value(&i).unwrap_or_default();
        value["running"] = json!(running.contains(&i.id));
        if i.icon.as_deref() == Some("custom") {
            if let Ok(Some(data_url)) = engine.instances.read_icon(&i.id).await {
                value["customIcon"] = json!(data_url);
            }
        }
        instances.push(value);
    }
    let mut downloads = serde_json::to_value(engine.jobs.list()?)?
        .as_array()
        .cloned()
        .unwrap_or_default();
    downloads.extend(
        engine
            .local
            .downloads()
            .await
            .into_iter()
            .map(|j| serde_json::to_value(j).unwrap_or_default()),
    );
    let minecraft_accounts: Vec<Value> = engine
        .accounts
        .list()
        .await?
        .into_iter()
        .map(|a| {
            json!({
                "id": a.id,
                "username": a.name,
                "selected": a.active,
                "name": a.name,
                "active": a.active,
                "owned": a.owned,
            })
        })
        .collect();
    Ok(
        json!({"instances":instances,"minecraftAccounts":minecraft_accounts,"localServers":engine.local.list().await?,"downloads":downloads}),
    )
}
pub async fn versions() -> Result<Value> {
    Ok(serde_json::to_value(metadata::versions().await?)?)
}
pub async fn loader_versions(game: &str, loader: &str) -> Result<Value> {
    match loader {
        "vanilla" => Ok(json!([])),
        "fabric" | "quilt" | "forge" | "neoforge" => Ok(serde_json::to_value(
            crate::game_core::loaders::versions(loader, game).await?,
        )?),
        _ => bail!("This loader is not available yet"),
    }
}
pub fn capabilities() -> Value {
    json!({"loaders":["vanilla","fabric","quilt","forge","neoforge"],"contentInstall":true,"automaticJava":true,"instanceFiles":true,"modManager":true,"instanceBackups":true,"preview":true})
}

async fn windows_version() -> Result<Option<String>> {
    #[cfg(windows)]
    {
        let ver = windows_version::OsVersion::current();
        Ok(Some(format!("{}.{}.{}", ver.major, ver.minor, ver.build)))
    }
    #[cfg(not(windows))]
    {
        Ok(None)
    }
}
async fn queue_install(id: String, name: String) -> Result<String> {
    let engine = get().await?;
    let job = engine.jobs.begin(&id, &name)?;
    let job_id = job.id.clone();
    tokio::spawn(async move {
        let permit = tokio::select! {
            _=job.cancel.cancelled()=>{engine.jobs.finish(&job.id,false,true);return},
            permit=engine.slots.acquire()=>permit,
        };
        let Ok(_permit) = permit else {
            engine.jobs.finish(&job.id, false, false);
            return;
        };
        let result = async {
            job.cancel.check()?;
            let os_version = windows_version().await?;
            crate::game_core::install::instance(
                &engine.instances,
                &engine.cache,
                &id,
                &job.cancel,
                os_version.as_deref(),
                |p| {
                    engine
                        .jobs
                        .report(&job.id, p.phase, p.verified_bytes, p.total_bytes)
                },
            )
            .await?;
            if cfg!(windows) {
                resolve_java(&id, &job.cancel, |phase, done, total| {
                    engine.jobs.report(&job.id, phase.into(), done, total)
                })
                .await?;
            }
            Ok::<_, anyhow::Error>(())
        }
        .await;
        engine
            .jobs
            .finish(&job.id, result.is_ok(), job.cancel.check().is_err());
    });
    Ok(job_id)
}
#[derive(Clone, Default, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateInstanceOptions {
    pub icon: Option<String>,
    pub group: Option<String>,
    pub memory: Option<u32>,
    pub java_path: Option<String>,
    pub jvm_args: Option<String>,
    pub resolution: Option<[u32; 2]>,
    pub fullscreen: Option<bool>,
    pub update_channel: Option<String>,
}

pub async fn create_instance(
    name: String,
    game_version: String,
    loader: String,
    loader_version: String,
) -> Result<Value> {
    create_instance_with_options(
        name,
        game_version,
        loader,
        loader_version,
        CreateInstanceOptions::default(),
    )
    .await
}

pub async fn create_instance_with_options(
    name: String,
    game_version: String,
    loader: String,
    loader_version: String,
    options: CreateInstanceOptions,
) -> Result<Value> {
    if !matches!(
        loader.as_str(),
        "vanilla" | "fabric" | "quilt" | "forge" | "neoforge"
    ) || (loader == "vanilla" && !loader_version.is_empty())
    {
        bail!("Choose a supported loader. More loaders are being added.")
    }
    let engine = get().await?;
    metadata::version_id(&game_version)?;
    if !metadata::versions()
        .await?
        .iter()
        .any(|v| v.id == game_version)
    {
        bail!("Choose a version from the official Minecraft list")
    }
    let resolved = if matches!(loader.as_str(), "fabric" | "quilt" | "forge" | "neoforge") {
        Some(
            crate::game_core::loaders::resolve_version(&loader, &game_version, &loader_version)
                .await?,
        )
    } else {
        None
    };
    let prefs = preferences().await?;
    let mem = options.memory.unwrap_or(prefs.memory);
    let java = options
        .java_path
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .unwrap_or(prefs.java_path);
    let record = engine
        .instances
        .create(name, game_version, loader, resolved, mem, java)
        .await?;
    let icon_val = match options.icon {
        Some(raw) => engine.instances.save_icon(&record.id, Some(&raw)).await?,
        None => None,
    };
    let clean_group = options
        .group
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty());
    let clean_jvm = options
        .jvm_args
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty());
    let clean_chan = options
        .update_channel
        .map(|s| s.trim().to_string())
        .filter(|s| matches!(s.as_str(), "release" | "beta" | "alpha"));
    if icon_val.is_some()
        || clean_group.is_some()
        || clean_jvm.is_some()
        || options.resolution.is_some()
        || options.fullscreen.is_some()
        || clean_chan.is_some()
    {
        engine
            .instances
            .change(&record.id, |i| {
                if let Some(iv) = icon_val {
                    i.icon = Some(iv);
                }
                if clean_group.is_some() {
                    i.group = clean_group;
                }
                if clean_jvm.is_some() {
                    i.jvm_args = clean_jvm;
                }
                if options.resolution.is_some() {
                    i.resolution = options.resolution;
                }
                if options.fullscreen.is_some() {
                    i.fullscreen = options.fullscreen;
                }
                if clean_chan.is_some() {
                    i.update_channel = clean_chan;
                }
            })
            .await?;
    }
    let job = queue_install(record.id.clone(), record.name).await?;
    Ok(json!({"jobId":job,"instanceId":record.id}))
}
pub async fn duplicate_instance(id: String, name: Option<String>) -> Result<Value> {
    assert_writable(&id).await?;
    let engine = get().await?;
    let source = engine.instances.get(&id).await?;
    let target_name = match name.map(|s| s.trim().to_string()).filter(|s| !s.is_empty()) {
        Some(n) => {
            if n.chars().count() > 80 {
                n.chars().take(80).collect()
            } else {
                n
            }
        }
        None => {
            let base = format!("{} (Copy)", source.name);
            if base.chars().count() > 80 {
                let suffix = " (Copy)";
                let keep = 80usize.saturating_sub(suffix.chars().count());
                format!(
                    "{}{}",
                    source.name.chars().take(keep).collect::<String>().trim_end(),
                    suffix
                )
            } else {
                base
            }
        }
    };
    let duplicated = engine.instances.duplicate(&id, &target_name).await?;
    Ok(serde_json::to_value(duplicated)?)
}
pub async fn retry_instance(id: String) -> Result<String> {
    let engine = get().await?;
    let record = engine.instances.get(&id).await?;
    if !matches!(record.state.as_str(), "created" | "failed" | "cancelled") {
        bail!("This instance is not waiting for an installation retry")
    }
    queue_install(record.id, record.name).await
}
pub async fn delete_instance(id: &str) -> Result<()> {
    let engine = get().await?;
    let running = engine.games.running().await?;
    if running.contains(&id.to_string()) {
        bail!("Cannot delete an instance while the game is running");
    }
    engine.instances.delete(id).await?;
    Ok(())
}
async fn resolve_java(
    id: &str,
    cancel: &Cancellation,
    report: impl FnMut(&str, u64, u64) + Send,
) -> Result<String> {
    let engine = get().await?;
    let record = engine.instances.get(id).await?;
    if !matches!(record.java_path.as_str(), "auto" | "java") {
        return Ok(record.java_path);
    }
    let path = engine.instances.path(id)?.join("runtime/plan.json");
    let meta = tokio::fs::symlink_metadata(&path).await?;
    if !meta.is_file() || meta.file_type().is_symlink() || meta.len() > 4 * 1024 * 1024 {
        bail!("Invalid installed launch plan")
    }
    let plan: crate::game_core::plan::Plan = serde_json::from_slice(&tokio::fs::read(path).await?)?;
    if plan.version != record.game_version {
        bail!("Installed files do not match this instance")
    }
    // A compatible explicitly selected PATH Java can be kept. Automatic mode
    // installs the metadata-required major in the launcher's own local directory.
    if record.java_path == "java"
        && crate::game_core::launch::java_check("java", plan.java_major)
            .await
            .is_ok()
    {
        return Ok("java".into());
    }
    let java = engine.java.ensure(plan.java_major, cancel, report).await?;
    java.to_str()
        .map(String::from)
        .context("Java path is not valid Unicode")
}
async fn queue_java(id: String) -> Result<String> {
    let engine = get().await?;
    let record = engine.instances.get(&id).await?;
    let job = engine
        .jobs
        .begin_kind(&id, &format!("Java for {}", record.name), "java")?;
    let key = job.id.clone();
    tokio::spawn(async move {
        let result = resolve_java(&id, &job.cancel, |phase, done, total| {
            engine.jobs.report(&job.id, phase.into(), done, total)
        })
        .await;
        engine
            .jobs
            .finish(&job.id, result.is_ok(), job.cancel.check().is_err());
    });
    Ok(key)
}
pub async fn launch(id: String) -> Result<Value> {
    launch_with_events(id, |_, _| {}, |_| {}).await
}

pub async fn launch_with_events(
    id: String,
    on_stage: impl Fn(&str, &str) + Send + Sync,
    on_exit: impl FnOnce(std::process::ExitStatus) + Send + 'static,
) -> Result<Value> {
    on_stage("checking", "Checking files...");
    if !cfg!(windows) {
        bail!("Minecraft play is available on Windows in this first preview")
    }
    let engine = get().await?;
    // Reserve before Java/account/hook work so repeated Play requests cannot
    // execute hooks twice or launch while another job changes game files.
    assert_writable(&id).await?;
    let _launch = engine.reserve_launch(&id)?;
    if engine.instances.get(&id).await?.state != "installed" {
        bail!("Finish installing this instance before playing")
    }
    let record = engine.instances.get(&id).await?;
    let prefs = preferences().await.unwrap_or_default();
    on_stage("java", "Preparing Java...");
    let java_job = engine
        .jobs
        .begin_kind(&id, &format!("Java for {}", record.name), "java")?;
    let result = resolve_java(&id, &java_job.cancel, |phase, done, total| {
        engine.jobs.report(&java_job.id, phase.into(), done, total)
    })
    .await;
    engine.jobs.finish(
        &java_job.id,
        result.is_ok(),
        java_job.cancel.check().is_err(),
    );
    let java = result?;
    on_stage("mods", "Loading mods...");
    let session = engine.accounts.session().await?;
    let version = windows_version().await?;
    let jvm_args = record
        .jvm_args
        .as_deref()
        .filter(|s| !s.trim().is_empty())
        .or_else(|| (!prefs.jvm_args.trim().is_empty()).then_some(prefs.jvm_args.as_str()));
    let resolution = record
        .resolution
        .or(Some([prefs.default_width, prefs.default_height]));
    let fullscreen = record.fullscreen.unwrap_or(prefs.fullscreen);
    let game_dir = engine.instances.game_dir(&id).await?;
    if let Some(hook) = record
        .pre_launch
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty())
    {
        crate::game_core::launch::run_hook(hook, &game_dir).await?;
    }
    process_finished_games(engine).await;
    on_stage("starting", "Starting Minecraft...");
    let pid = engine
        .games
        .start(
            &engine.instances,
            &id,
            session,
            version.as_deref(),
            &java,
            jvm_args,
            resolution,
            fullscreen,
            record.post_exit.clone(),
        )
        .await?;
    on_stage("running", "Minecraft is running");
    let _ = engine
        .instances
        .change(&id, |i| {
            i.last_played = Some(chrono::Utc::now().to_rfc3339());
        })
        .await;
    let watch_id = id.clone();
    tokio::spawn(async move {
        if let Ok(engine) = get().await {
            if let Some(status) = engine.games.poll_until_exited(&watch_id, pid).await {
                process_finished_games(engine).await;
                on_exit(status);
            }
        }
    });
    Ok(json!({"processId":pid}))
}
pub async fn stop(id: String) -> Result<()> {
    let engine = get().await?;
    engine.games.stop(&id).await?;
    process_finished_games(engine).await;
    Ok(())
}
pub async fn edit(id: String, name: String, memory: u32, java_path: String) -> Result<()> {
    let engine = get().await?;
    if engine.games.running().await?.contains(&id) {
        bail!("Close this game before changing its settings")
    }
    let defaults = preferences().await?;
    engine
        .instances
        .change(&id, |i| {
            i.name = name.trim().into();
            i.memory = memory;
            i.java_path = if java_path.trim().is_empty() {
                defaults.java_path
            } else {
                java_path
            };
        })
        .await?;
    Ok(())
}

// Missing fields mean "leave unchanged"; explicit null means "clear override".
fn nullable_patch<'de, D, T>(deserializer: D) -> std::result::Result<Option<Option<T>>, D::Error>
where D: serde::Deserializer<'de>, T: serde::Deserialize<'de> {
    Ok(Some(<Option<T> as serde::Deserialize>::deserialize(deserializer)?))
}

#[derive(Clone, Default, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InstanceMetaPatch {
    pub name: Option<String>,
    pub memory: Option<u32>,
    pub java_path: Option<String>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub icon: Option<Option<String>>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub group: Option<Option<String>>,
    pub pinned: Option<bool>,
    pub favourite: Option<bool>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub jvm_args: Option<Option<String>>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub resolution: Option<Option<[u32; 2]>>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub fullscreen: Option<Option<bool>>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub pre_launch: Option<Option<String>>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub post_exit: Option<Option<String>>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub update_channel: Option<Option<String>>,
    #[serde(default, deserialize_with = "nullable_patch")]
    pub notes: Option<Option<String>>,
}

pub async fn update_instance_meta(id: &str, patch: InstanceMetaPatch) -> Result<Value> {
    let engine = get().await?;
    let needs_idle = patch.name.is_some()
        || patch.memory.is_some()
        || patch.java_path.is_some()
        || patch.jvm_args.is_some()
        || patch.resolution.is_some()
        || patch.fullscreen.is_some()
        || patch.pre_launch.is_some()
        || patch.post_exit.is_some();
    if needs_idle && (engine.is_launching(id) || engine.games.running().await?.iter().any(|k| k == id)) {
        bail!("Close this game before changing launch or memory settings");
    }
    if let Some(Some(ref raw)) = patch.jvm_args {
        let trimmed = raw.trim();
        if !trimmed.is_empty() {
            crate::game_core::launch::split_command_args(trimmed)
                .context("Invalid custom JVM arguments")?;
        }
    }
    if let Some(Some(ref raw)) = patch.pre_launch {
        let trimmed = raw.trim();
        if !trimmed.is_empty() {
            let parts = crate::game_core::launch::split_command_args(trimmed)
                .context("Invalid pre-launch hook command")?;
            if parts.first().is_some_and(|p| p.is_empty()) {
                bail!("Pre-launch hook cannot start with an empty executable name");
            }
        }
    }
    if let Some(Some(ref raw)) = patch.post_exit {
        let trimmed = raw.trim();
        if !trimmed.is_empty() {
            let parts = crate::game_core::launch::split_command_args(trimmed)
                .context("Invalid post-exit hook command")?;
            if parts.first().is_some_and(|p| p.is_empty()) {
                bail!("Post-exit hook cannot start with an empty executable name");
            }
        }
    }
    let defaults = preferences().await?;
    let icon_override = match &patch.icon {
        Some(Some(raw)) => Some(engine.instances.save_icon(id, Some(raw)).await?),
        Some(None) => Some(engine.instances.save_icon(id, None).await?),
        None => None,
    };
    let updated = engine
        .instances
        .change(id, |i| {
            if let Some(ref name) = patch.name {
                i.name = name.trim().into();
            }
            if let Some(mem) = patch.memory {
                i.memory = mem;
            }
            if let Some(ref jp) = patch.java_path {
                i.java_path = if jp.trim().is_empty() {
                    defaults.java_path.clone()
                } else {
                    jp.trim().into()
                };
            }
            if let Some(iv) = icon_override {
                i.icon = iv;
            }
            if let Some(g) = patch.group {
                i.group = g.map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
            }
            if let Some(p) = patch.pinned {
                i.pinned = p;
            }
            if let Some(f) = patch.favourite {
                i.favourite = f;
            }
            if let Some(ja) = patch.jvm_args {
                i.jvm_args = ja.map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
            }
            if let Some(res) = patch.resolution {
                i.resolution = res;
            }
            if let Some(fs) = patch.fullscreen {
                i.fullscreen = fs;
            }
            if let Some(pre) = patch.pre_launch {
                i.pre_launch = pre.map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
            }
            if let Some(post) = patch.post_exit {
                i.post_exit = post.map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
            }
            if let Some(ch) = patch.update_channel {
                i.update_channel = ch.map(|s| s.trim().to_string()).filter(|s| matches!(s.as_str(), "release" | "beta" | "alpha"));
            }
            if let Some(notes) = patch.notes {
                i.notes = notes.map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
            }
        })
        .await?;
    let mut val = serde_json::to_value(&updated)?;
    if updated.icon.as_deref() == Some("custom") {
        if let Ok(Some(data_url)) = engine.instances.read_icon(id).await {
            val["customIcon"] = json!(data_url);
        }
    }
    Ok(val)
}

pub async fn repair_instance(id: String) -> Result<String> {
    assert_writable(&id).await?;
    let engine = get().await?;
    let record = engine.instances.get(&id).await?;
    if record.state == "installed" {
        engine
            .instances
            .transition(&id, &["installed"], "created")
            .await?;
    }
    queue_install(record.id, record.name).await
}
pub async fn instance_folder(id: &str) -> Result<PathBuf> {
    get().await?.instances.game_dir(id).await
}
pub async fn assert_writable(id: &str) -> Result<()> {
    let engine = get().await?;
    engine.instances.get(id).await?;
    if engine.is_launching(id) || engine.games.running().await?.iter().any(|key| key == id) {
        bail!("Close this game before changing its files")
    }
    if engine
        .jobs
        .list()?
        .iter()
        .any(|j| j.instance == id && matches!(j.status.as_str(), "queued" | "running"))
    {
        bail!("Wait for this instance's current task to finish")
    }
    Ok(())
}
pub async fn list_files(id: &str, path: &str) -> Result<Value> {
    let e = get().await?;
    Ok(serde_json::to_value(
        e.files.list(&e.instances, id, path).await?,
    )?)
}
pub async fn read_text(id: &str, path: &str) -> Result<Value> {
    let e = get().await?;
    Ok(serde_json::to_value(
        e.files.read(&e.instances, id, path).await?,
    )?)
}
pub async fn read_image(id: &str, relative: &str) -> Result<String> {
    use base64::Engine as _;
    let engine = get().await?;
    let path = crate::game_core::files::resolve(&engine.instances, id, relative, false).await?;
    let meta = tokio::fs::metadata(&path).await?;
    if !meta.is_file() || meta.len() > 10 * 1024 * 1024 {
        bail!("Choose an image smaller than 10 MiB");
    }
    let ext = path
        .extension()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_lowercase();
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "webp" => "image/webp",
        _ => bail!("Unsupported image format"),
    };
    let bytes = tokio::fs::read(&path).await?;
    let b64 = base64::engine::general_purpose::STANDARD.encode(&bytes);
    Ok(format!("data:{mime};base64,{b64}"))
}
pub async fn list_trash(id: &str) -> Result<Value> {
    let e = get().await?;
    Ok(serde_json::to_value(
        e.files.trash_list(&e.instances, id).await?,
    )?)
}
pub async fn list_mods(id: &str) -> Result<Value> {
    let e = get().await?;
    Ok(serde_json::to_value(
        crate::game_core::mods::list(&e.instances, &e.files, id).await?,
    )?)
}
pub async fn toggle_mod(id: &str, path: &str, enabled: bool) -> Result<()> {
    assert_writable(id).await?;
    let e = get().await?;
    crate::game_core::mods::toggle(&e.instances, &e.files, id, path, enabled).await
}
pub async fn import_mod(
    id: &str,
    file_name: Option<&str>,
    bytes_base64: Option<&str>,
    source_path: Option<&str>,
) -> Result<Value> {
    assert_writable(id).await?;
    let e = get().await?;
    let imported = if let Some(path) = source_path.map(str::trim).filter(|s| !s.is_empty()) {
        crate::game_core::mods::import_path(&e.instances, id, std::path::Path::new(path)).await?
    } else {
        let name = file_name
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .context("Choose a .jar mod file to import")?;
        let encoded = bytes_base64
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .context("Selected .jar mod file is empty")?;
        use base64::Engine as _;
        let bytes = base64::engine::general_purpose::STANDARD
            .decode(encoded)
            .context("Could not read selected .jar mod file")?;
        crate::game_core::mods::import_bytes(&e.instances, id, name, &bytes).await?
    };
    Ok(serde_json::to_value(imported)?)
}
pub async fn list_backups(id: &str) -> Result<Value> {
    let e = get().await?;
    Ok(serde_json::to_value(
        crate::game_core::backups::list(&e.instances, id).await?,
    )?)
}
pub async fn backup_action(
    id: &str,
    action: &str,
    backup_id: Option<&str>,
    name: Option<&str>,
) -> Result<Value> {
    assert_writable(id).await?;
    let e = get().await?;
    match action {
        "create" => Ok(serde_json::to_value(
            crate::game_core::backups::create(&e.instances, id, name).await?,
        )?),
        "restore" => {
            let bid = backup_id
                .map(str::trim)
                .filter(|s| !s.is_empty())
                .context("Choose a backup to restore")?;
            Ok(serde_json::to_value(
                crate::game_core::backups::restore(&e.instances, id, bid).await?,
            )?)
        }
        "delete" => {
            let bid = backup_id
                .map(str::trim)
                .filter(|s| !s.is_empty())
                .context("Choose a backup to delete")?;
            crate::game_core::backups::delete(&e.instances, id, bid).await?;
            Ok(json!({"ok": true}))
        }
        _ => bail!("This backup action is not available"),
    }
}
pub async fn file_action(
    id: &str,
    action: &str,
    path: &str,
    target: Option<&str>,
    content: Option<&str>,
    expected: Option<&str>,
) -> Result<Value> {
    assert_writable(id).await?;
    let e = get().await?;
    match action {
        "mkdir" => e.files.mkdir(&e.instances, id, path).await?,
        "rename" => {
            e.files
                .rename(
                    &e.instances,
                    id,
                    path,
                    target.context("Choose a new file name")?,
                )
                .await?
        }
        "trash" => return Ok(json!({"trashId":e.files.trash(&e.instances,id,path).await?})),
        "restore" => e.files.restore(&e.instances, id, path).await?,
        "save" => {
            return Ok(
                json!({"sha256":e.files.write(&e.instances,id,path,content.context("File text missing")?,expected).await?}),
            )
        }
        _ => bail!("This file action is not available"),
    };
    Ok(json!({"ok":true}))
}
pub async fn logs(id: &str) -> Result<String> {
    get().await?.games.logs(id).await
}
pub async fn minecraft_login(
    cancel: &Cancellation,
    prompt: impl FnMut(crate::game_core::auth::DevicePrompt),
) -> Result<()> {
    get().await?.accounts.login(cancel, prompt).await
}
pub async fn minecraft_logout(id: &str) -> Result<()> {
    get().await?.accounts.remove(id).await
}
pub async fn minecraft_select(id: &str) -> Result<()> {
    get().await?.accounts.select(id).await
}
pub async fn game_running() -> bool {
    match get().await {
        Ok(e) => e
            .games
            .running()
            .await
            .map(|v| !v.is_empty())
            .unwrap_or(false),
        Err(_) => false,
    }
}

pub async fn install_content(
    instance_id: Option<String>,
    project_id: String,
    content_type: String,
    version_id: Option<String>,
    world: Option<String>,
) -> Result<Value> {
    let engine = get().await?;
    if content_type == "modpack" {
        if instance_id.is_some() {
            bail!("Modpacks create a new instance")
        }
        let version = version_id
            .as_deref()
            .filter(|v| !v.is_empty())
            .context("Choose a modpack version")?;
        let prepared = crate::game_core::content::prepare_modpack(&project_id, version).await?;
        let prefs = preferences().await?;
        let record = engine
            .instances
            .create(
                prepared.name,
                prepared.game_version,
                prepared.loader,
                prepared.loader_version,
                prefs.memory,
                prefs.java_path,
            )
            .await?;
        let dir = engine.instances.path(&record.id)?;
        let temp = dir.join(format!(".modpack-{}.tmp", uuid::Uuid::new_v4()));
        if let Err(e) = async {
            use tokio::io::AsyncWriteExt;
            let mut f = tokio::fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&temp)
                .await?;
            f.write_all(&prepared.mrpack_bytes).await?;
            f.sync_all().await?;
            drop(f);
            tokio::fs::rename(&temp, dir.join("modpack.mrpack")).await?;
            Ok::<_, anyhow::Error>(())
        }
        .await
        {
            let _ = tokio::fs::remove_file(&temp).await;
            let _ = tokio::fs::remove_dir_all(&dir).await;
            return Err(e);
        }
        let instance_id = record.id.clone();
        let job_id = queue_install(record.id, record.name).await?;
        return Ok(json!({"instanceId": instance_id, "jobId": job_id}));
    }
    let id = instance_id
        .filter(|s| !s.is_empty())
        .context("Choose an instance")?;
    assert_writable(&id).await?;
    let instance = engine.instances.get(&id).await?;
    let (label, planned) = crate::game_core::content::plan_project_install(
        &instance,
        &project_id,
        &content_type,
        version_id.as_deref(),
        world.as_deref(),
    )
    .await?;
    let job_id = queue_content_install(id.clone(), format!("{label} for {}", instance.name), planned).await?;
    Ok(json!({"instanceId": id, "jobId": job_id}))
}
async fn queue_content_install(
    id: String,
    job_name: String,
    planned: Vec<crate::game_core::content::VerifiedFile>,
) -> Result<String> {
    let engine = get().await?;
    let job = engine.jobs.begin_content(&id, &job_name, planned.clone())?;
    let job_id = job.id.clone();
    tokio::spawn(async move {
        let permit = tokio::select! {
            _=job.cancel.cancelled()=>{engine.jobs.finish(&job.id,false,true);return},
            permit=engine.slots.acquire()=>permit,
        };
        let Ok(_permit) = permit else {
            engine.jobs.finish(&job.id, false, false);
            return;
        };
        let result = crate::game_core::content::install_files(
            &engine.instances,
            &engine.cache,
            &id,
            &planned,
            &job.cancel,
            |p| {
                engine
                    .jobs
                    .report(&job.id, p.phase, p.verified_bytes, p.total_bytes)
            },
        )
        .await;
        engine
            .jobs
            .finish(&job.id, result.is_ok(), job.cancel.check().is_err());
    });
    Ok(job_id)
}
pub async fn download_action(id: &str, action: &str) -> Result<()> {
    let engine = get().await?;
    let job = engine.jobs.get(id)?;
    match action {
        "cancel" if matches!(job.status.as_str(), "queued" | "running") => job.cancel.cancel(),
        "retry" if matches!(job.status.as_str(), "failed" | "cancelled") => {
            let record = engine.instances.get(&job.instance).await?;
            match job.kind.as_str() {
                "java" => {
                    queue_java(record.id).await?;
                }
                "install" => {
                    queue_install(record.id, record.name).await?;
                }
                "content" => {
                    let files = job
                        .content_files
                        .context("This content download cannot be retried")?;
                    assert_writable(&record.id).await?;
                    queue_content_install(record.id, job.name, files).await?;
                }
                _ => bail!("This download action is not available"),
            }
        }
        _ => bail!("This download action is not available"),
    };
    Ok(())
}
pub async fn clear_finished_downloads() -> Result<()> {
    let engine = get().await?;
    engine.jobs.clear_finished();
    Ok(())
}
#[derive(Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct Preferences {
    pub prefs_version: u32,
    pub memory: u32,
    pub java_path: String,
    pub theme: String,
    pub ui_scale: u32,
    pub reduced_motion: bool,
    pub density: String,
    pub on_launch: String,
    pub confirm_launch: bool,
    pub max_concurrent_downloads: u32,
    pub default_width: u32,
    pub default_height: u32,
    pub fullscreen: bool,
    pub jvm_args: String,
    pub diagnostics_enabled: bool,
    pub onboarding_completed: bool,
    pub announcements_enabled: bool,
    pub solara_hub_enabled: bool,
    pub auto_update_enabled: bool,
    pub groups: Vec<String>,
}
impl Default for Preferences {
    fn default() -> Self {
        Self {
            prefs_version: 2,
            memory: 4096,
            java_path: "auto".into(),
            theme: "dawn-gold".into(),
            ui_scale: 100,
            reduced_motion: false,
            density: "comfortable".into(),
            on_launch: "keep".into(),
            confirm_launch: false,
            max_concurrent_downloads: 4,
            default_width: 854,
            default_height: 480,
            fullscreen: false,
            jvm_args: String::new(),
            diagnostics_enabled: true,
            onboarding_completed: false,
            announcements_enabled: true,
            solara_hub_enabled: true,
            auto_update_enabled: true,
            groups: Vec::new(),
        }
    }
}
async fn read_preferences_from_dir(data: &Path) -> Result<Preferences> {
    let path = data.join("preferences.json");
    match tokio::fs::metadata(&path).await {
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(Preferences::default()),
        Ok(meta) => {
            if !meta.is_file() || meta.len() > 65536 {
                bail!("Invalid local settings")
            };
            let mut raw_val: serde_json::Value =
                serde_json::from_slice(&tokio::fs::read(&path).await?)?;
            let had_version = raw_val
                .get("prefsVersion")
                .and_then(|v| v.as_u64())
                .unwrap_or(0);
            let mut needs_persist = had_version < 2;
            if let Some(obj) = raw_val.as_object_mut() {
                if !matches!(
                    obj.get("onLaunch").and_then(|v| v.as_str()),
                    Some("keep" | "minimize")
                ) {
                    // Migrate any legacy/invalid/non-string onLaunch (such as "hide" or "close") to "keep" so Play never closes Solara unexpectedly.
                    obj.insert("onLaunch".into(), serde_json::json!("keep"));
                    needs_persist = true;
                }
                if had_version < 2 {
                    obj.insert("prefsVersion".into(), serde_json::json!(2));
                }
            }
            let mut value: Preferences = serde_json::from_value(raw_val)?;
            if !matches!(value.on_launch.as_str(), "keep" | "minimize") {
                value.on_launch = "keep".into();
                needs_persist = true;
            }
            value.prefs_version = 2;
            validate_preferences(&value)?;
            if needs_persist {
                let _ = write_json(&path, &value).await;
            }
            Ok(value)
        }
        Err(e) => Err(e.into()),
    }
}
pub async fn preferences() -> Result<Preferences> {
    read_preferences_from_dir(&get().await?.data).await
}
fn validate_preferences(value: &Preferences) -> Result<()> {
    if !(512..=65536).contains(&value.memory)
        || value.java_path.trim().is_empty()
        || value.java_path.contains('\0')
        || !(80..=125).contains(&value.ui_scale)
        || !(1..=8).contains(&value.max_concurrent_downloads)
        || !(320..=7680).contains(&value.default_width)
        || !(240..=4320).contains(&value.default_height)
        || !matches!(value.on_launch.as_str(), "keep" | "minimize")
        || value.jvm_args.contains('\0')
        || value.jvm_args.len() > 2000
    {
        bail!("Choose valid launcher settings")
    };
    Ok(())
}
pub async fn save_preferences(memory: u32, java_path: String) -> Result<()> {
    let mut value = preferences().await.unwrap_or_default();
    value.memory = memory;
    value.java_path = java_path;
    validate_preferences(&value)?;
    write_json(&get().await?.data.join("preferences.json"), &value).await
}
pub async fn save_preferences_full(mut value: Preferences) -> Result<Preferences> {
    value.prefs_version = 2;
    if !matches!(value.on_launch.as_str(), "keep" | "minimize") {
        value.on_launch = "keep".into();
    }
    value.java_path = value.java_path.trim().to_string();
    if value.java_path.is_empty() {
        value.java_path = "auto".into();
    }
    value.jvm_args = value.jvm_args.trim().to_string();
    value.groups = value
        .groups
        .into_iter()
        .map(|g| g.trim().to_string())
        .filter(|g| !g.is_empty() && g.chars().count() <= 60 && !g.chars().any(char::is_control))
        .take(50)
        .collect();
    validate_preferences(&value)?;
    let engine = get().await?;
    write_json(&engine.data.join("preferences.json"), &value).await?;
    engine.slots.set_limit(value.max_concurrent_downloads);
    Ok(value)
}

// ---------------------------------------------------------------------------
// Extended Engine Commands (packs, worlds, screenshots, logs, updates, skins)
// ---------------------------------------------------------------------------

pub async fn list_packs(id: &str, kind: &str, world: Option<&str>) -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::list_packs(&engine.instances, &engine.files, id, kind, world).await?,
    )?)
}

pub async fn toggle_pack(id: &str, _kind: &str, path: &str, enabled: bool) -> Result<()> {
    assert_writable(id).await?;
    let engine = get().await?;
    extras::toggle_pack(&engine.instances, &engine.files, id, path, enabled).await
}

pub async fn import_pack(
    id: &str,
    kind: &str,
    world: Option<&str>,
    file_name: Option<&str>,
    bytes_base64: Option<&str>,
    source_path: Option<&str>,
) -> Result<Value> {
    assert_writable(id).await?;
    let engine = get().await?;
    let (resolved_name, raw_bytes) = if let Some(b64) = bytes_base64 {
        let name = file_name.context("Choose a file name")?.to_string();
        use base64::Engine as _;
        let decoded = base64::engine::general_purpose::STANDARD
            .decode(b64)
            .context("Could not decode pack archive")?;
        (name, decoded)
    } else if let Some(src) = source_path {
        let p = PathBuf::from(src);
        let meta = tokio::fs::symlink_metadata(&p).await?;
        if !meta.is_file() || meta.file_type().is_symlink() || meta.len() > 256 * 1024 * 1024 {
            bail!("Selected file is missing or larger than 256 MiB");
        }
        let name = file_name
            .map(String::from)
            .or_else(|| p.file_name().map(|s| s.to_string_lossy().to_string()))
            .context("Choose a valid file")?;
        let data = tokio::fs::read(&p).await?;
        (name, data)
    } else {
        bail!("No pack file supplied");
    };
    let entry = extras::import_pack(
        &engine.instances,
        id,
        kind,
        world,
        &resolved_name,
        &raw_bytes,
    )
    .await?;
    Ok(serde_json::to_value(entry)?)
}

pub async fn check_content_updates(id: &str) -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::check_content_updates(&engine.instances, id).await?,
    )?)
}

pub async fn apply_content_updates(id: &str, items: Vec<Value>) -> Result<Value> {
    assert_writable(id).await?;
    let engine = get().await?;
    let parsed: Vec<extras::ContentUpdateItem> = items
        .into_iter()
        .map(serde_json::from_value)
        .collect::<std::result::Result<Vec<_>, _>>()?;
    let cancel = Cancellation::default();
    let count = parsed.len();
    extras::apply_content_updates(&engine.instances, &engine.cache, id, &parsed, &cancel, |_, _, _| {})
        .await?;
    Ok(json!({ "updated": count }))
}

pub async fn list_worlds(id: &str) -> Result<Value> {
    let engine = get().await?;
    let running = engine.games.running().await?.iter().any(|k| k == id);
    Ok(serde_json::to_value(
        extras::list_worlds(&engine.instances, id, running).await?,
    )?)
}

pub async fn rename_world(id: &str, folder: &str, new_name: &str) -> Result<()> {
    assert_writable(id).await?;
    let engine = get().await?;
    extras::rename_world(&engine.instances, &engine.files, id, folder, new_name).await
}

pub async fn list_screenshots(instance_id: Option<&str>) -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::list_screenshots(&engine.instances, instance_id).await?,
    )?)
}

pub async fn read_screenshot_image(instance_id: &str, path: &str) -> Result<String> {
    let engine = get().await?;
    extras::read_screenshot_image(&engine.instances, instance_id, path).await
}

pub async fn list_disk_logs(id: &str) -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::list_disk_logs(&engine.instances, id).await?,
    )?)
}

pub async fn read_disk_log(id: &str, name: &str) -> Result<String> {
    let engine = get().await?;
    extras::read_disk_log(&engine.instances, id, name).await
}

pub async fn detect_java_runtimes() -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::detect_java_runtimes(&engine.data.join("java-runtimes")).await,
    )?)
}

pub async fn storage_summary() -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::storage_summary(&engine.data).await,
    )?)
}

pub async fn clear_unused_cache() -> Result<Value> {
    let engine = get().await?;
    let freed = extras::clear_unused_cache(&engine.data).await?;
    Ok(json!({ "freedBytes": freed }))
}

pub async fn saved_skins_list() -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::saved_skins_list(&engine.data.join("skins")).await?,
    )?)
}

pub async fn saved_skins_save(
    id: Option<String>,
    name: String,
    variant: String,
    png_data_url: String,
) -> Result<Value> {
    let engine = get().await?;
    Ok(serde_json::to_value(
        extras::saved_skins_save(
            &engine.data.join("skins"),
            id.as_deref(),
            &name,
            &variant,
            &png_data_url,
        )
        .await?,
    )?)
}

pub async fn saved_skins_delete(id: &str) -> Result<()> {
    let engine = get().await?;
    extras::saved_skins_delete(&engine.data.join("skins"), id).await
}

pub async fn fetch_profile_skins_and_capes() -> Result<Value> {
    let engine = get().await?;
    let session = engine.accounts.session().await?;
    extras::fetch_profile_skins_and_capes(&session).await
}

pub async fn upload_minecraft_skin(variant: &str, png_data_url: &str) -> Result<Value> {
    let engine = get().await?;
    let session = engine.accounts.session().await?;
    extras::upload_minecraft_skin(&session, variant, png_data_url).await
}

pub async fn set_minecraft_cape(cape_id: Option<&str>) -> Result<()> {
    let engine = get().await?;
    let session = engine.accounts.session().await?;
    extras::set_minecraft_cape(&session, cape_id).await
}

pub async fn export_diagnostics() -> Result<Value> {
    let engine = get().await?;
    let instances = engine.instances.list().await.unwrap_or_default();
    let prefs = preferences().await.unwrap_or_default();
    if !prefs.diagnostics_enabled {
        bail!("Enable local diagnostics in Settings before exporting a report");
    }
    let storage = extras::storage_summary(&engine.data).await;
    let javas = extras::detect_java_runtimes(&engine.data.join("java-runtimes")).await;
    Ok(json!({
        "generatedAt": chrono::Utc::now().to_rfc3339(),
        "launcherVersion": env!("CARGO_PKG_VERSION"),
        "os": std::env::consts::OS,
        "arch": std::env::consts::ARCH,
        "instanceCount": instances.len(),
        "instancesSummary": instances.iter().map(|i| json!({
            "loader": i.loader,
            "gameVersion": i.game_version,
            "state": i.state,
            "memory": i.memory
        })).collect::<Vec<_>>(),
        "javaCount": javas.len(),
        "storage": diagnostic_storage(&storage),
        "preferences": {
            "theme": prefs.theme,
            "memory": prefs.memory,
            "maxConcurrentDownloads": prefs.max_concurrent_downloads,
            "reducedMotion": prefs.reduced_motion
        }
    }))
}

// Reports are shareable: keep counts/bytes and exclude local paths and names.
fn diagnostic_storage(storage: &extras::StorageSummary) -> Value {
    json!({
        "totalBytes": storage.total_bytes, "cacheBytes": storage.cache_bytes,
        "instancesBytes": storage.instances_bytes, "javaBytes": storage.java_bytes,
        "skinsBytes": storage.skins_bytes, "backupsBytes": storage.backups_bytes,
    })
}

pub async fn data_dir() -> Result<PathBuf> {
    Ok(get().await?.data.clone())
}
pub async fn create_local(
    name: String,
    version: String,
    java_path: String,
    memory: u32,
    port: u16,
    eula: bool,
) -> Result<String> {
    get()
        .await?
        .local
        .create(ServerConfig {
            id: String::new(),
            name,
            version,
            java_path,
            memory,
            port,
            eula,
        })
        .await
}
pub async fn stop_all() -> Result<()> {
    if let Some(engine) = ENGINE.get() {
        engine.local.stop_all().await?
    };
    Ok(())
}

pub const CLEAN_SLATE_V23_SENTINEL: &str = ".clean_slate_v23_reset";

/// Robust recursive directory removal that handles read-only files and folders on Windows and Unix.
pub async fn robust_remove_dir_all(path: &std::path::Path) -> std::io::Result<()> {
    if !path.exists() {
        return Ok(());
    }
    // Attempt standard async removal first
    if let Ok(()) = tokio::fs::remove_dir_all(path).await {
        return Ok(());
    }
    // If standard removal failed (e.g. read-only file/folder permissions on Windows/Unix),
    // clear read-only attributes recursively and retry.
    let target = path.to_path_buf();
    tokio::task::spawn_blocking(move || -> std::io::Result<()> {
        fn make_writable(p: &std::path::Path) {
            if let Ok(meta) = std::fs::symlink_metadata(p) {
                let mut perms = meta.permissions();
                if perms.readonly() {
                    #[allow(clippy::permissions_set_readonly_false)]
                    perms.set_readonly(false);
                    let _ = std::fs::set_permissions(p, perms);
                }
                // Only recurse into real directories, never follow symlinks or junctions
                if !meta.file_type().is_symlink() && meta.is_dir() {
                    if let Ok(entries) = std::fs::read_dir(p) {
                        for entry in entries.flatten() {
                            make_writable(&entry.path());
                        }
                    }
                }
            }
        }
        make_writable(&target);
        std::fs::remove_dir_all(&target)
    })
    .await
    .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?
}

/// Retire the V23 reset without touching any instance, world or account data.
/// A missing marker on a later upgrade is not consent to repeat that old reset.
pub async fn migrate_clean_slate_v23(data: &std::path::Path) -> Result<bool> {
    let sentinel = data.join(CLEAN_SLATE_V23_SENTINEL);
    if tokio::fs::try_exists(&sentinel).await? {
        return Ok(false);
    }
    tokio::fs::create_dir_all(data.join("custom-instances")).await?;
    use tokio::io::AsyncWriteExt;
    // create_new makes this safe across concurrent first starts. Never replace a
    // marker that an earlier version wrote, and never move/remove user folders.
    match tokio::fs::OpenOptions::new().write(true).create_new(true).open(&sentinel).await {
        Ok(mut file) => {
            file.write_all(format!(
                "migration=clean_slate_v23_reset\nstatus=retired_preserving_data\nrecorded_at={}\nversion={}\n",
                chrono::Utc::now().to_rfc3339(), env!("CARGO_PKG_VERSION")
            ).as_bytes()).await?;
            Ok(true)
        }
        Err(err) if err.kind() == std::io::ErrorKind::AlreadyExists => Ok(false),
        Err(err) => Err(err.into()),
    }
}

/// Clean up stale temporary files, download caches, and legacy remnants
/// while strictly preserving user data (instances, saves, configs, mods, accounts, and servers).
pub async fn cleanup_stale_files(data: &std::path::Path) {
    // 1. Stale temporary directories and legacy engine remnants in launcher root
    for dir_name in &["app-update"] {
        let path = data.join(dir_name);
        if path.exists() {
            let _ = tokio::fs::remove_dir_all(&path).await;
        }
    }

    // 2. Game file verification temporary directory
    let verified_tmp = data.join("verified-game-files").join(".tmp");
    if verified_tmp.exists() {
        let _ = tokio::fs::remove_dir_all(&verified_tmp).await;
    }

    // 3. Stale temporary files and wiping staging folders in launcher root data folder
    if let Ok(mut rd) = tokio::fs::read_dir(data).await {
        while let Ok(Some(entry)) = rd.next_entry().await {
            let file_name = entry.file_name().to_string_lossy().to_string();
            // Old reset staging folders can hold the only recoverable copy of
            // a world. Preserve them for explicit user recovery/removal.
            if file_name.starts_with(".wiping-instances-") || file_name.starts_with(".stale-instances-") {
                continue;
            }
            let is_stale_temp = file_name.ends_with(".tmp")
                || file_name.ends_with(".pending")
                || (file_name.starts_with(".solara-") && file_name.contains(".tmp"))
                || (file_name.starts_with(".modpack-") && file_name.ends_with(".tmp"));
            if is_stale_temp {
                if let Ok(meta) = entry.metadata().await {
                    if meta.is_file() {
                        let _ = tokio::fs::remove_file(entry.path()).await;
                    }
                }
            }
        }
    }

    // 4. Stale staging directories and temporary files inside custom-instances
    // User saves (game/saves), configs, mods (*.jar), and identity remain strictly untouched.
    let instances_dir = data.join("custom-instances");
    if let Ok(mut rd) = tokio::fs::read_dir(&instances_dir).await {
        while let Ok(Some(entry)) = rd.next_entry().await {
            if let Ok(file_type) = entry.file_type().await {
                if file_type.is_dir() {
                    let inst_dir = entry.path();
                    // Interrupted backup/restore staging directories
                    let backups_dir = inst_dir.join("backups");
                    if let Ok(mut b_rd) = tokio::fs::read_dir(&backups_dir).await {
                        while let Ok(Some(b_entry)) = b_rd.next_entry().await {
                            let name = b_entry.file_name().to_string_lossy().to_string();
                            // Restore staging may contain original worlds in
                            // rollback-saves after an interruption. Keep it.
                            if name.starts_with(".create-stage-") {
                                let _ = tokio::fs::remove_dir_all(b_entry.path()).await;
                            } else if name.ends_with(".tmp") || name.starts_with(".solara-backup-")
                            {
                                let _ = tokio::fs::remove_file(b_entry.path()).await;
                            }
                        }
                    }
                    // Clean temporary files in instance root and game folders
                    for sub in &["", "game", "game/mods"] {
                        let target_sub = if sub.is_empty() {
                            inst_dir.clone()
                        } else {
                            inst_dir.join(sub)
                        };
                        if let Ok(mut sub_rd) = tokio::fs::read_dir(&target_sub).await {
                            while let Ok(Some(f_entry)) = sub_rd.next_entry().await {
                                let name = f_entry.file_name().to_string_lossy().to_string();
                                if name.starts_with(".solara-") && name.ends_with(".tmp")
                                {
                                    if let Ok(m) = f_entry.metadata().await {
                                        if m.is_file() {
                                            let _ = tokio::fs::remove_file(f_entry.path()).await;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn cleanup_stale_files_removes_unwanted_and_preserves_user_data() -> Result<()> {
        let dir =
            std::env::temp_dir().join(format!("solara-cleanup-test-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        // 1. Setup stale/unwanted files and directories
        let app_update = data.join("app-update");
        tokio::fs::create_dir_all(&app_update).await?;
        tokio::fs::write(app_update.join("update.zip"), b"old update bytes").await?;

        let theseus = data.join("theseus");
        tokio::fs::create_dir_all(&theseus).await?;
        tokio::fs::write(theseus.join("legacy.dat"), b"old engine").await?;

        let verified_tmp = data.join("verified-game-files").join(".tmp");
        tokio::fs::create_dir_all(&verified_tmp).await?;
        tokio::fs::write(verified_tmp.join("chunk.tmp"), b"temp asset").await?;

        let root_tmp = data.join("stale.tmp");
        tokio::fs::write(&root_tmp, b"temp").await?;
        let root_solara_tmp = data.join(".solara-content-123.tmp");
        tokio::fs::write(&root_solara_tmp, b"temp").await?;

        // 2. Setup custom-instances with both valid data and stale staging
        let inst_dir = data.join("custom-instances").join("test-instance");
        let saves_dir = inst_dir.join("game").join("saves").join("World1");
        tokio::fs::create_dir_all(&saves_dir).await?;
        let level_dat = saves_dir.join("level.dat");
        tokio::fs::write(&level_dat, b"player save world").await?;

        let mods_dir = inst_dir.join("game").join("mods");
        tokio::fs::create_dir_all(&mods_dir).await?;
        let sodium_jar = mods_dir.join("sodium-mc1.20.jar");
        tokio::fs::write(&sodium_jar, b"real mod jar").await?;
        let stale_mod_tmp = mods_dir.join(".solara-mod-temp.tmp");
        tokio::fs::write(&stale_mod_tmp, b"partial mod download").await?;

        let instance_json = inst_dir.join("instance.json");
        tokio::fs::write(&instance_json, b"{\"id\":\"test-instance\"}").await?;

        let backups_dir = inst_dir.join("backups");
        let stage_dir = backups_dir.join(".create-stage-999");
        tokio::fs::create_dir_all(&stage_dir).await?;
        tokio::fs::write(stage_dir.join("partial.zip"), b"partial backup").await?;

        let recovery_world = backups_dir.join(".restore-stage-999/rollback-saves/World1/level.dat");
        tokio::fs::create_dir_all(recovery_world.parent().unwrap()).await?;
        tokio::fs::write(&recovery_world, b"original world before interrupted restore").await?;
        let user_tmp = mods_dir.join("user-settings.tmp");
        tokio::fs::write(&user_tmp, b"user file, not a launcher staging file").await?;
        let valid_backup = backups_dir.join("backup-1.zip");
        tokio::fs::write(&valid_backup, b"completed backup").await?;

        // 3. Setup accounts, local servers, and preferences (must be preserved)
        let accounts_dir = data.join("custom-minecraft-accounts");
        tokio::fs::create_dir_all(&accounts_dir).await?;
        let account_file = accounts_dir.join("accounts.json");
        tokio::fs::write(&account_file, b"{\"accounts\":[]}").await?;

        let servers_dir = data.join("local-servers").join("survival-server");
        tokio::fs::create_dir_all(&servers_dir).await?;
        let server_props = servers_dir.join("server.properties");
        tokio::fs::write(&server_props, b"motd=Solara Server").await?;

        let preferences = data.join("preferences.json");
        tokio::fs::write(&preferences, b"{\"theme\":\"dark\"}").await?;

        // Run cleanup
        cleanup_stale_files(data).await;

        // Verify unwanted/stale files were deleted
        assert!(!app_update.exists(), "app-update dir must be deleted");
        assert!(theseus.exists(), "legacy engine data must be preserved for recovery");
        assert!(
            !verified_tmp.exists(),
            "verified-game-files/.tmp must be deleted"
        );
        assert!(!root_tmp.exists(), "root .tmp file must be deleted");
        assert!(
            !root_solara_tmp.exists(),
            "root .solara-*.tmp must be deleted"
        );
        assert!(
            !stage_dir.exists(),
            "interrupted backup stage must be deleted"
        );
        assert!(
            !stale_mod_tmp.exists(),
            "stale mod download temp must be deleted"
        );

        // Verify all user data is strictly preserved
        assert_eq!(tokio::fs::read(&recovery_world).await?, b"original world before interrupted restore");
        assert!(user_tmp.exists(), "arbitrary user .tmp files must be preserved");
        assert!(level_dat.exists(), "saves/level.dat must be preserved");
        assert!(sodium_jar.exists(), "mods jar must be preserved");
        assert!(instance_json.exists(), "instance.json must be preserved");
        assert!(
            valid_backup.exists(),
            "completed backup zip must be preserved"
        );
        assert!(account_file.exists(), "account logins must be preserved");
        assert!(
            server_props.exists(),
            "server configurations must be preserved"
        );
        assert!(preferences.exists(), "preferences must be preserved");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[tokio::test]
    async fn retired_v23_migration_preserves_existing_data_without_marker() -> Result<()> {
        let dir =
            std::env::temp_dir().join(format!("solara-clean-slate-test-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        // Setup existing user instance data (simulating V-0.0.22 state)
        let old_inst = data.join("custom-instances").join("old-instance");
        let saves = old_inst.join("game").join("saves").join("MyWorld");
        tokio::fs::create_dir_all(&saves).await?;
        tokio::fs::write(saves.join("level.dat"), b"world data").await?;
        tokio::fs::write(old_inst.join("instance.json"), b"{\"id\":\"old-instance\"}").await?;

        // Setup accounts, servers, preferences (must be preserved)
        let accounts_dir = data.join("custom-minecraft-accounts");
        tokio::fs::create_dir_all(&accounts_dir).await?;
        let accounts_file = accounts_dir.join("accounts.json");
        tokio::fs::write(&accounts_file, b"{\"accounts\":[]}").await?;

        let servers_dir = data.join("local-servers").join("my-server");
        tokio::fs::create_dir_all(&servers_dir).await?;
        let server_props = servers_dir.join("server.properties");
        tokio::fs::write(&server_props, b"motd=Test").await?;

        let preferences = data.join("preferences.json");
        tokio::fs::write(&preferences, b"{\"theme\":\"dark\"}").await?;

        let sentinel = data.join(CLEAN_SLATE_V23_SENTINEL);
        assert!(!sentinel.exists(), "sentinel must not exist prior to migration");

        // Run migration for the first time
        let migrated = migrate_clean_slate_v23(data).await?;
        assert!(migrated, "first run must report migration performed");
        assert!(sentinel.exists(), "sentinel marker must be created");
        let marker_content = tokio::fs::read_to_string(&sentinel).await?;
        assert!(
            marker_content.contains("migration=clean_slate_v23_reset"),
            "sentinel must contain clean_slate_v23_reset identifier"
        );

        // Skipping V23 or losing its marker must never delete existing worlds.
        assert_eq!(tokio::fs::read(saves.join("level.dat")).await?, b"world data");
        assert!(old_inst.join("instance.json").exists());
        assert!(
            data.join("custom-instances").exists(),
            "custom-instances must exist as clean empty directory"
        );

        // Verify non-instance user data was strictly preserved
        assert!(accounts_file.exists(), "minecraft accounts must be preserved");
        assert!(server_props.exists(), "local servers must be preserved");
        assert!(preferences.exists(), "preferences must be preserved");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[tokio::test]
    async fn migrate_clean_slate_v23_idempotent_preserves_instances_on_subsequent_runs() -> Result<()> {
        let dir =
            std::env::temp_dir().join(format!("solara-clean-slate-idempotent-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        // First run: initializes sentinel
        let first = migrate_clean_slate_v23(data).await?;
        assert!(first, "first run should create sentinel");

        // User now creates a new instance on V-0.0.23
        let new_inst = data.join("custom-instances").join("v23-new-instance");
        let world = new_inst.join("game").join("saves").join("NewWorld");
        tokio::fs::create_dir_all(&world).await?;
        let level_dat = world.join("level.dat");
        tokio::fs::write(&level_dat, b"v23 world data").await?;
        let inst_json = new_inst.join("instance.json");
        tokio::fs::write(&inst_json, b"{\"id\":\"v23-new-instance\"}").await?;

        // Second run (e.g. app restart or subsequent launch): must NOT delete user instances
        let second = migrate_clean_slate_v23(data).await?;
        assert!(!second, "second run must report false (already migrated)");
        assert!(new_inst.exists(), "new instance must be strictly preserved on restart");
        assert!(level_dat.exists(), "user saves must be preserved on restart");
        assert!(inst_json.exists(), "instance.json must be preserved on restart");

        // Third run (e.g. simulated future V-0.0.24 update): must STILL NOT delete user instances
        let third = migrate_clean_slate_v23(data).await?;
        assert!(!third, "third run must report false");
        assert!(new_inst.exists(), "new instance must be strictly preserved on future updates");
        assert!(level_dat.exists(), "user saves must be preserved on future updates");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[tokio::test]
    async fn migrate_clean_slate_v23_fresh_install_initializes_sentinel_and_preserves() -> Result<()> {
        let dir =
            std::env::temp_dir().join(format!("solara-clean-slate-fresh-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        // In a completely fresh install, custom-instances does not exist yet
        let sentinel = data.join(CLEAN_SLATE_V23_SENTINEL);
        assert!(!sentinel.exists());
        assert!(!data.join("custom-instances").exists());

        let migrated = migrate_clean_slate_v23(data).await?;
        assert!(migrated, "fresh install must write sentinel marker");
        assert!(sentinel.exists(), "sentinel must exist");
        assert!(data.join("custom-instances").exists(), "custom-instances should be ready");

        // User creates instance
        let inst = data.join("custom-instances").join("first-play");
        tokio::fs::create_dir_all(&inst).await?;
        let inst_file = inst.join("instance.json");
        tokio::fs::write(&inst_file, b"{\"id\":\"first-play\"}").await?;

        // Next start
        let next = migrate_clean_slate_v23(data).await?;
        assert!(!next, "subsequent launch must do nothing");
        assert!(inst_file.exists(), "fresh user's instance must be preserved");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[tokio::test]
    async fn cleanup_stale_files_preserves_clean_slate_sentinel() -> Result<()> {
        let dir =
            std::env::temp_dir().join(format!("solara-clean-slate-sentinel-preservation-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        let sentinel = data.join(CLEAN_SLATE_V23_SENTINEL);
        tokio::fs::write(&sentinel, b"migration=clean_slate_v23_reset\n").await?;

        // Stale files that should be cleaned
        let stale_tmp = data.join("stale.tmp");
        tokio::fs::write(&stale_tmp, b"temp").await?;
        let solara_tmp = data.join(".solara-abc.tmp");
        tokio::fs::write(&solara_tmp, b"temp").await?;

        cleanup_stale_files(data).await;

        assert!(!stale_tmp.exists(), "stale .tmp should be deleted");
        assert!(!solara_tmp.exists(), "stale .solara-*.tmp should be deleted");
        assert!(sentinel.exists(), "clean slate sentinel marker must be strictly preserved");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[tokio::test]
    async fn retired_v23_migration_preserves_readonly_instance_files() -> Result<()> {
        let dir = std::env::temp_dir()
            .join(format!("solara-clean-slate-readonly-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        let inst = data.join("custom-instances").join("readonly-inst");
        let sub = inst.join("locked_folder");
        tokio::fs::create_dir_all(&sub).await?;
        let locked_file = sub.join("locked_file.txt");
        tokio::fs::write(&locked_file, b"cannot touch this easily").await?;

        // Mark file as readonly
        let meta = std::fs::metadata(&locked_file)?;
        let mut perms = meta.permissions();
        perms.set_readonly(true);
        std::fs::set_permissions(&locked_file, perms)?;

        // Execute migration
        let migrated = migrate_clean_slate_v23(data).await?;
        assert!(migrated, "migration should succeed even with read-only files");
        assert!(data.join(CLEAN_SLATE_V23_SENTINEL).exists(), "sentinel must be created");
        assert_eq!(tokio::fs::read(&locked_file).await?, b"cannot touch this easily");
        assert!(std::fs::metadata(&locked_file)?.permissions().readonly());
        assert!(inst.exists(), "existing instance must be preserved");
        let mut perms = std::fs::metadata(&locked_file)?.permissions();
        #[allow(clippy::permissions_set_readonly_false)]
        perms.set_readonly(false);
        std::fs::set_permissions(&locked_file, perms)?;
        assert!(data.join("custom-instances").exists(), "fresh custom-instances must exist");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[tokio::test]
    async fn cleanup_stale_files_preserves_recoverable_reset_directories() -> Result<()> {
        let dir = std::env::temp_dir()
            .join(format!("solara-clean-slate-wiping-cleanup-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        let wiping_dir = data.join(format!(".wiping-instances-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&wiping_dir).await?;
        tokio::fs::write(wiping_dir.join("remnant.bin"), b"leftover data").await?;

        cleanup_stale_files(data).await;

        assert_eq!(tokio::fs::read(wiping_dir.join("remnant.bin")).await?, b"leftover data");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[tokio::test]
    async fn migrate_clean_slate_v23_persists_sentinel_and_preserves_new_instances_on_fallback() -> Result<()> {
        let dir = std::env::temp_dir()
            .join(format!("solara-clean-slate-fallback-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        let data = dir.as_path();

        let inst = data.join("custom-instances").join("fallback-inst");
        tokio::fs::create_dir_all(&inst).await?;
        tokio::fs::write(inst.join("instance.json"), b"{\"id\":\"fallback-inst\"}").await?;

        // Run migration (first time)
        let first = migrate_clean_slate_v23(data).await?;
        assert!(first, "first migration must succeed");
        assert!(data.join(CLEAN_SLATE_V23_SENTINEL).exists(), "sentinel must exist");

        // User adds new instance on V23
        let user_inst = data.join("custom-instances").join("my-survival");
        tokio::fs::create_dir_all(&user_inst).await?;
        let user_file = user_inst.join("instance.json");
        tokio::fs::write(&user_file, b"{\"id\":\"my-survival\"}").await?;

        // Subsequent launch: must not wipe new instance
        let second = migrate_clean_slate_v23(data).await?;
        assert!(!second, "second run must do nothing");
        assert!(user_file.exists(), "new instance must be preserved");

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }

    #[test]
    fn diagnostic_storage_omits_private_paths_but_keeps_size_counts() {
        let storage = extras::StorageSummary {
            data_dir: "C:/Users/PRIVATE_FIXTURE/AppData/Local/Solara".into(),
            instances_dir: "C:/Users/PRIVATE_FIXTURE/worlds".into(),
            total_bytes: 21, cache_bytes: 1, instances_bytes: 2,
            java_bytes: 3, skins_bytes: 4, backups_bytes: 11,
        };
        let redacted = diagnostic_storage(&storage);
        assert_eq!(redacted["totalBytes"], 21);
        assert_eq!(redacted["backupsBytes"], 11);
        assert!(redacted.get("dataDir").is_none());
        assert!(redacted.get("instancesDir").is_none());
        assert!(!redacted.to_string().contains("PRIVATE_FIXTURE"));
    }

    #[test]
    fn instance_patch_distinguishes_missing_clear_and_override() {
        let missing: InstanceMetaPatch = serde_json::from_value(json!({})).unwrap();
        assert!(missing.notes.is_none());
        assert!(missing.fullscreen.is_none());
        let clear: InstanceMetaPatch = serde_json::from_value(json!({
            "notes":null,"group":null,"icon":null,"jvmArgs":null,"resolution":null,
            "fullscreen":null,"preLaunch":null,"postExit":null,"updateChannel":null
        })).unwrap();
        assert_eq!(clear.notes, Some(None)); assert_eq!(clear.group, Some(None));
        assert_eq!(clear.icon, Some(None)); assert_eq!(clear.jvm_args, Some(None));
        assert_eq!(clear.resolution, Some(None)); assert_eq!(clear.fullscreen, Some(None));
        assert_eq!(clear.pre_launch, Some(None)); assert_eq!(clear.post_exit, Some(None));
        assert_eq!(clear.update_channel, Some(None));
        let set: InstanceMetaPatch = serde_json::from_value(json!({"notes":"Keep this", "fullscreen":false})).unwrap();
        assert_eq!(set.notes, Some(Some("Keep this".into())));
        assert_eq!(set.fullscreen, Some(Some(false)));
    }

    #[tokio::test]
    async fn download_gate_enforces_and_resizes_concurrency_limits() -> Result<()> {
        use std::sync::Arc;
        let gate = Arc::new(DownloadGate::new(2));
        let p1 = gate.acquire().await?;
        let p2 = gate.acquire().await?;

        // Third acquire must wait while 2 permits are held
        let gate_wait = gate.clone();
        let waiting = tokio::spawn(async move { gate_wait.acquire().await.map(|_| ()) });
        tokio::task::yield_now().await;
        assert!(!waiting.is_finished(), "third acquire must block at limit=2");

        // Raising limit dynamically wakes the waiting task immediately
        gate.set_limit(3);
        tokio::time::timeout(std::time::Duration::from_secs(1), waiting)
            .await
            .context("raised limit should wake waiting acquire")??
            .unwrap();

        // Lowering limit prevents new acquires while still allowing active permits to drain
        gate.set_limit(1);
        let gate_blocked = gate.clone();
        let blocked = tokio::spawn(async move { gate_blocked.acquire().await.map(|_| ()) });
        tokio::task::yield_now().await;
        assert!(!blocked.is_finished(), "should block at lowered limit=1 while active=2");

        drop(p1);
        drop(p2);
        tokio::time::timeout(std::time::Duration::from_secs(1), blocked)
            .await
            .context("dropping permits should wake acquire under limit=1")??
            .unwrap();
        Ok(())
    }

    #[tokio::test]
    async fn read_preferences_from_dir_persists_max_concurrent_downloads() -> Result<()> {
        let dir = std::env::temp_dir()
            .join(format!("solara-prefs-test-{}", uuid::Uuid::new_v4()));
        tokio::fs::create_dir_all(&dir).await?;
        assert_eq!(read_preferences_from_dir(&dir).await?.max_concurrent_downloads, 4);

        let mut custom = Preferences::default();
        custom.max_concurrent_downloads = 6;
        write_json(&dir.join("preferences.json"), &custom).await?;
        assert_eq!(read_preferences_from_dir(&dir).await?.max_concurrent_downloads, 6);

        // Legacy fields ("discord", "sidebarExpanded", "hide" onLaunch) from older preferences.json migrate cleanly
        tokio::fs::write(
            dir.join("preferences.json"),
            r#"{"memory":4096,"javaPath":"auto","onLaunch":"hide","discord":true,"sidebarExpanded":true,"maxConcurrentDownloads":5}"#,
        )
        .await?;
        let migrated = read_preferences_from_dir(&dir).await?;
        assert_eq!(migrated.max_concurrent_downloads, 5);
        assert_eq!(migrated.on_launch, "keep");
        assert_eq!(migrated.prefs_version, 2);

        // Even v2 preferences with "close" must migrate to "keep" and persist so Play never closes the launcher
        tokio::fs::write(
            dir.join("preferences.json"),
            r#"{"prefsVersion":2,"memory":4096,"javaPath":"auto","onLaunch":"close"}"#,
        )
        .await?;
        let migrated_v2 = read_preferences_from_dir(&dir).await?;
        assert_eq!(migrated_v2.on_launch, "keep");
        assert_eq!(migrated_v2.prefs_version, 2);
        let persisted_v2: serde_json::Value =
            serde_json::from_slice(&tokio::fs::read(dir.join("preferences.json")).await?)?;
        assert_eq!(persisted_v2["onLaunch"], "keep");

        // "minimize" remains valid across both v1->v2 migration and v2 preferences
        tokio::fs::write(
            dir.join("preferences.json"),
            r#"{"memory":4096,"javaPath":"auto","onLaunch":"minimize"}"#,
        )
        .await?;
        let migrated_minimize = read_preferences_from_dir(&dir).await?;
        assert_eq!(migrated_minimize.on_launch, "minimize");
        assert_eq!(migrated_minimize.prefs_version, 2);

        tokio::fs::write(
            dir.join("preferences.json"),
            r#"{"prefsVersion":2,"memory":4096,"javaPath":"auto","onLaunch":"minimize"}"#,
        )
        .await?;
        assert_eq!(read_preferences_from_dir(&dir).await?.on_launch, "minimize");

        // Non-string onLaunch also migrates safely to "keep" without failing deserialization
        tokio::fs::write(
            dir.join("preferences.json"),
            r#"{"prefsVersion":2,"memory":4096,"javaPath":"auto","onLaunch":123}"#,
        )
        .await?;
        let migrated_invalid_type = read_preferences_from_dir(&dir).await?;
        assert_eq!(migrated_invalid_type.on_launch, "keep");

        // validate_preferences rejects "close" and "hide"
        let mut invalid = Preferences::default();
        invalid.on_launch = "close".into();
        assert!(validate_preferences(&invalid).is_err());
        invalid.on_launch = "hide".into();
        assert!(validate_preferences(&invalid).is_err());

        let _ = tokio::fs::remove_dir_all(&dir).await;
        Ok(())
    }
}
